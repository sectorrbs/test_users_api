<template>
    <svg class="loader" xmlns="http://www.w3.org/2000/svg" version="1.1" width="512"
         height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><path d="M234.545 0h42.908v78.589h-42.908z" fill="#000000" opacity="1" data-original="#000000"></path><path
        d="M234.545 433.411h42.908V512h-42.908z" opacity="1" fill="#00000052" data-original="#00000052"></path><path
        d="m303.27 428.398 39.733-16.22 29.708 72.778-39.733 16.22z" opacity="1" fill="#00000058"
        data-original="#00000058"></path><path d="m303.235 83.608 29.708-72.777 39.733 16.22-29.708 72.776z" opacity="1"
                                               fill="#00000094" data-original="#00000094"></path><path
        d="m139.471 484.965 29.708-72.777 39.733 16.219-29.708 72.777z" opacity="1" fill="#00000046"
        data-original="#00000046"></path><path d="m10.894 332.94 72.778-29.708 16.218 39.73-72.777 29.709z" opacity="1"
                                               fill="#00000036" data-original="#00000036"></path><path
        d="m412.226 169.1 72.776-29.708 16.218 39.73-72.776 29.708z" opacity="1" fill="#00000082"
        data-original="#00000082"></path><path d="m10.9 179.123 16.218-39.73L99.895 169.1l-16.218 39.73z" opacity="1"
                                               fill="#00000024" data-original="#00000024"></path><path
        d="m412.23 342.862 16.218-39.73 72.775 29.708-16.218 39.73z" opacity="1" fill="#00000070"
        data-original="#00000070"></path><path d="m366.214 115.389 55.563-55.563 30.338 30.338-55.563 55.563z"
                                               opacity="1" fill="#00000088" data-original="#00000088"></path><path
        d="m59.774 421.79 55.563-55.563 30.338 30.338-55.563 55.563z" opacity="1" fill="#00000040"
        data-original="#00000040"></path><path d="M59.792 90.159 90.13 59.82l55.563 55.563-30.338 30.338z" opacity="1"
                                               fill="#00000018" data-original="#00000018"></path><path
        d="m366.195 396.642 30.338-30.339 55.563 55.564-30.338 30.338z" opacity="1" fill="#00000064"
        data-original="#00000064"></path><path d="M-.001 234.548H78.59v42.908H-.001z" opacity="1" fill="#00000030"
                                               data-original="#00000030"></path><path
        d="M433.408 234.548h78.593v42.908h-78.593z" opacity="1" fill="#00000076" data-original="#00000076"
        class=""></path></g></svg>
</template>
